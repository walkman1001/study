package gocoin

import (
	// This file use to be only to make "go get" working.
)

const Version = "1.10.2"
