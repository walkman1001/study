This is the source code of [gocoin.pl](https://gocoin.pl) website
