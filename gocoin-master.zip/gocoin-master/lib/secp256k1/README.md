Implementation of this package has been based on source code created by Pieter Wuille.

 * https://github.com/bitcoin/secp256k1


Use go compiler version 1.7 or higher, for significant performance boost.