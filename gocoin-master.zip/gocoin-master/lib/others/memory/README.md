# memory

Package memory originated from "modernc.org/memory"
New address: https://gitlab.com/cznic/memory

It is used by Gocoin client node to allocate UTXO records in memory.
The idea is to improve performance by disablig GC over UTXO records.