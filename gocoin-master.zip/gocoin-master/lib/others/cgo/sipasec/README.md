Building
==============


Unix
--------------

1. Execute "sudo apt-get install libgmp3-dev"

2. Download secp256k1:
 * https://github.com/bitcoin/secp256k1

3. Follow "Build steps" section from README.md, iuncluding the install part



Windows
--------------

Use MSYS2 - http://www.msys2.org/
