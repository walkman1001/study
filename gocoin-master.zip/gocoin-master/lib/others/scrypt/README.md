Package scrypt originated from "golang.org/x/crypto/scrypt"
Package pbkdf2 originated from "golang.org/x/crypto/pbkdf2"

Shipped with Gocoin source code for security and convenience.
