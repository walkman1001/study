Since currently qdb is only used for peers management,
using the membinds has a little effect and thertefore
this functionality has been disabled.

If you want to switch OS memory biding on, just copy
all go files from this folder one level up.
