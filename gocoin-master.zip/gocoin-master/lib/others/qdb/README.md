From Gocoin version 1.9.0 it is no longer used for UTXO db.
Now it is only used for maintaining peers database.
