# bip39

Package bip39 originated from "github.com/tyler-smith/go-bip39"

Shipped with Gocoin source code for security and convenience.

Only English mnemonics supported by this version.
