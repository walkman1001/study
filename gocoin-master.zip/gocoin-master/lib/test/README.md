These test vector files come from the original bitcoin project:

 * https://github.com/bitcoin/bitcoin/tree/master/src/test/data
